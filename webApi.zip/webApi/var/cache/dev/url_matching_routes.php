<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/FormularioPromo' => [[['_route' => 'FormularioPromo', '_controller' => 'App\\Controller\\ContactoMailController::FormularioPromo'], null, ['POST' => 0], null, false, false, null]],
        '/FormularioPromo2' => [[['_route' => 'FormularioPromo2', '_controller' => 'App\\Controller\\ContactoMailController::FormularioPromo2'], null, ['POST' => 0], null, false, false, null]],
        '/contacto/formFooter' => [[['_route' => 'formFooter', '_controller' => 'App\\Controller\\ContactoMailController::FormularioFooter'], null, ['POST' => 0], null, false, false, null]],
        '/formSuscribite' => [[['_route' => 'formSuscribite', '_controller' => 'App\\Controller\\ContactoMailController::FormularioSuscribite'], null, ['POST' => 0], null, false, false, null]],
        '/FormularioContacto' => [[['_route' => 'FormularioContacto', '_controller' => 'App\\Controller\\ContactoMailController::FormularioContacto'], null, ['POST' => 0], null, false, false, null]],
        '/FormluarioPlanCanje' => [[['_route' => 'formPlanCanje', '_controller' => 'App\\Controller\\ContactoMailController::FormularioPlanCanje'], null, ['POST' => 0], null, false, false, null]],
        '/formModal' => [[['_route' => 'formContacto', '_controller' => 'App\\Controller\\ContactoMailController::formModal'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
