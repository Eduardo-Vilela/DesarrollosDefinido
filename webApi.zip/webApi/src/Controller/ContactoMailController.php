<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;


class ContactoMailController extends AbstractController
{
    /**
     * @Route("/FormularioPromo", name="FormularioPromo" , methods={"POST"})
     */
    public function FormularioPromo(\Swift_Mailer $mailer,Request $request ): Response
    {   

        $post=$request->getContent();
        $datosContacto= json_decode($post);
        
        $name= $datosContacto->name;
        $telefono= $datosContacto->telefono;
        $mail= $datosContacto->email;
        $desarrollo= $datosContacto->desarrollo;
        
          $message = (new \Swift_Message('Hello Email'))
        ->setFrom('info@desarrollosdelsud.com.ar')
        ->setTo('marketingdesarrollosdelsud@gmail.com')
        ->setSubject('Formulario Promo!')
        ->addPart(
            '
                <p><strong> Nombre: </strong> '. $name.'</p><br>                
                <p><strong> Teléfono: </strong> '. $telefono.'</p><br>
                <p><strong> Email: </strong> '. $mail.'</p><br>
                <p><strong> Desarrollo: </strong> '. $desarrollo.'</p><br>
            '
            );       

        $mailer->send($message);
        return $this->json([
            'message' => 'FormularioPromo!',
            'path' => 'src/Controller/ContactoMailController.php',
        ]);

    }
    
    
     /**
     * @Route("/FormularioPromo2", name="FormularioPromo2" , methods={"POST"})
     */
    public function FormularioPromo2(\Swift_Mailer $mailer,Request $request ): Response
    {   

        $post=$request->getContent();
        $datosContacto= json_decode($post);
        
        $nombre= $datosContacto->nombre;
        $phone= $datosContacto->phone;
        $correo= $datosContacto->correo;
        $lote= $datosContacto->lote;
        
          $message = (new \Swift_Message('Hello Email'))
        ->setFrom('info@desarrollosdelsud.com.ar')
        ->setTo('marketingdesarrollosdelsud@gmail.com')
        ->setSubject('Formulario Promo!')
        ->addPart(
            '
            <html>
                <p><strong> Nombre: </strong> '. $nombre.'</p><br>                
                <p><strong> Teléfono: </strong> '. $phone.'</p><br>
                <p><strong> Email: </strong> '. $correo.'</p><br>
                <p><strong> Desarrollo: </strong> '. $lote.'</p><br>
            </html>','text/html'
            );       

        $mailer->send($message);
        return $this->json([
            'message' => 'FormularioPromo!',
            'path' => 'src/Controller/ContactoMailController.php',
        ]);

    }


     /**
     * @Route("/contacto/formFooter", name="formFooter" , methods={"POST"})
     */
    public function FormularioFooter(\Swift_Mailer $mailer,Request $request ): Response
    {   

        $post=$request->getContent();
        $datosContacto= json_decode($post);
        
        $nombre= $datosContacto->nombre;
        $telefono= $datosContacto->telefono;
        $email= $datosContacto->email;
        $mensaje = $datosContacto->mensaje;
        
        $message = (new \Swift_Message('Hello Email'))
        ->setFrom('info@desarrollosdelsud.com.ar')
        ->setTo('edumix22@gmail.com')
        ->setSubject('Formulario de Movimientos de Suelo')
        ->addPart(
            '<html> 
                <p><strong> Nombre y Apellido: </strong> '. $nombre.'</p><br>                
                <p><strong> Email: </strong> '. $email.'</p><br>
                <p><strong> Teléfono: </strong> '. $telefono.'</p><br>
                <p><strong> Mensaje: </strong> '. $mensaje.'</p> 
            </html>','text/html'
            );       

        $mailer->send($message);
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/ContactoMailController.php',
        ]);

    }

    /**
     * @Route("/formSuscribite", name="formSuscribite" , methods={"POST"})
     */
    public function FormularioSuscribite(\Swift_Mailer $mailer,Request $request ): Response
    {   
        $post=$request->getContent();
        $datosContacto= json_decode($post);
        

        $email= $datosContacto->email;

        
        $message = (new \Swift_Message('Hello Email'))  
        ->setFrom('info@desarrollosdelsud.com.ar')
        ->setTo('edumix22@gmail.com')
        ->setSubject('Formulario de Premoldeado')
        ->addPart(
            '<html> 
                <p> <strong> Email:  </strong> '. $email.' </p>
            </html>','text/html'
            );       
        // you can remove the following code if you don't define a text version for your emails       
        $mailer->send($message);
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/ContactoMailController.php',
        ]);
    }
   
    /**
     * @Route("/FormularioContacto", name="FormularioContacto" , methods={"POST"})
     */
    public function FormularioContacto(\Swift_Mailer $mailer,Request $request ): Response
    {   
        $post=$request->getContent();
        $datosContacto= json_decode($post);
        
        $name=$datosContacto->name;
        $email= $datosContacto->email;
        $telefono= $datosContacto->telefono;
        $mensaje = $datosContacto->mensaje;
        
        $message = (new \Swift_Message('Hello Email'))  
        ->setFrom('info@desarrollosdelsud.com.ar')
        ->setTo('edumix22@gmail.com')
        ->setSubject('Formulario de Hormigonera')
        ->addPart(
            '<html> 
                <p> <strong> Nombre: </strong> '. $name.'</p> 
                <p> <strong> Email:  </strong> '. $email.' </p>
                <p> <strong> Teléfono:  </strong> '. $telefono.' </p>
                <p> <strong> Mensaje:  </strong> '. $mensaje.' </p> 
            </html>','text/html'
            );       
        // you can remove the following code if you don't define a text version for your emails       
        $mailer->send($message);
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/ContactoMailController.php',
        ]);
    }

    
    /**
     * @Route("/FormluarioPlanCanje", name="formPlanCanje" , methods={"POST"})
     */
    public function FormularioPlanCanje(\Swift_Mailer $mailer,Request $request ): Response
    {   
        $post=$request->getContent();
        $datosContacto= json_decode($post);
        
        $modeloDeAuto=$datosContacto->modeloDeAuto;
        $marca= $datosContacto->marca;
        $kilometros= $datosContacto->kilometros;
        $valorDelAuto = $datosContacto->valorDelAuto;
        $name=$datosContacto->nombre;
        $email= $datosContacto->email;
        $telefono= $datosContacto->telefono;
        
        $message = (new \Swift_Message('Hello Email'))  
        ->setFrom('info@desarrollosdelsud.com.ar')
        ->setTo('edumix22@gmail.com')
        ->setSubject('Formulario de Contacto')
        ->addPart(
            '<html> 
                <p> <strong> Modelo del auto: </strong> '. $modeloDelAuto.'</p> 
                <p> <strong> Marca:  </strong> '. $marca.' </p>
                <p> <strong> Kilometros:  </strong> '. $kilometros.' </p>
                <p> <strong> Valor del auto:  </strong> '. $valorDelAuto.' </p> 
                <p> <strong> Nombre y Apellido: </strong> '. $name.'</p> 
                <p> <strong> Email:  </strong> '. $email.' </p>
                <p> <strong> Teléfono:  </strong> '. $telefono.' </p>
            </html>','text/html'
            );       
        // you can remove the following code if you don't define a text version for your emails       
        $mailer->send($message);
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/ContactoMailController.php',
        ]);
    }
   

        /**
     * @Route("/formModal", name="formContacto" , methods={"POST"})
     */
    public function formModal(\Swift_Mailer $mailer,Request $request ): Response
    {   
        $post=$request->getContent();
        $datosContacto= json_decode($post);
        
        $name=$datosContacto->name;
        $email= $datosContacto->email;
        $telefono= $datosContacto->telefono;
        
        $message = (new \Swift_Message('Hello Email'))  
        ->setFrom('info@desarrollosdelsud.com.ar')
        ->setTo('edumix22@gmail.com')
        ->setSubject('Formulario de Hormigonera')
        ->addPart(
            '<html> 
                <p> <strong> Nombre y Apellido: </strong> '. $name.'</p> 
                <p> <strong> Email:  </strong> '. $email.' </p>
                <p> <strong> Teléfono:  </strong> '. $telefono.' </p>
            </html>','text/html'
            );       
        // you can remove the following code if you don't define a text version for your emails       
        $mailer->send($message);
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/ContactoMailController.php',
        ]);
    }
}
